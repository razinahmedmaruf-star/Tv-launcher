package com.ayan.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Calendar

data class AppItem(val label: String, val pkg: String, val icon: Drawable, val banner: Boolean)

data class Tile(
    val title: String,
    val sub: String,
    val icon: Drawable?,
    val emoji: String?,
    val banner: Boolean,
    val onClick: () -> Unit,
    val onLong: (() -> Unit)?
)

class MainActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val allApps = ArrayList<AppItem>()
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private val tabViews = ArrayList<TextView>()
    private var currentTab = 0
    private var heroTitle: TextView? = null
    private var heroSub: TextView? = null
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun c(hex: String) = Color.parseColor(hex)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ---------- storage ----------
    private fun favs(): MutableSet<String> =
        HashSet(prefs.getStringSet("favs", emptySet()) ?: emptySet())

    private fun recents(): MutableList<String> =
        (prefs.getString("recents", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        render()
        content.post { content.requestFocus() }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (currentTab != 0) tabViews[0].requestFocus() else {
            scroll.smoothScrollTo(0, 0)
            content.requestFocus()
        }
    }

    // ---------- UI skeleton ----------
    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(c("#0E1116"), c("#1A2030"))
            )
        }
        root.addView(buildTopBar(), LinearLayout.LayoutParams(MATCH, WRAP))

        scroll = ScrollView(this).apply {
            clipChildren = false
            clipToPadding = false
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(0, 0, 0, dp(40))
        }
        scroll.addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return root
    }

    private fun chipBg(color: Int) = GradientDrawable().apply {
        cornerRadius = dp(40).toFloat()
        setColor(color)
    }

    private fun refreshChip(tv: TextView) {
        val f = tv.isFocused
        val sel = tv.tag == true
        tv.background = chipBg(if (f) Color.WHITE else if (sel) 0x33FFFFFF else 0x00000000)
        tv.setTextColor(if (f) Color.BLACK else Color.WHITE)
    }

    private fun chip(label: String): TextView = TextView(this).apply {
        text = label
        textSize = 18f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(20), dp(10), dp(20), dp(10))
        isFocusable = true
        isClickable = true
        setOnFocusChangeListener { v, _ -> refreshChip(v as TextView) }
        refreshChip(this)
    }

    private fun buildTopBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
            setPadding(dp(40), dp(20), dp(48), dp(8))
        }
        fun lp() = LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(4), 0, dp(4), 0) }

        val search = chip("🔍  Search").apply { setOnClickListener { openSearch() } }
        bar.addView(search, lp())
        bar.addView(View(this), LinearLayout.LayoutParams(dp(24), 1))

        val names = listOf("For you", "Apps")
        for ((i, name) in names.withIndex()) {
            val t = chip(name)
            t.tag = (i == 0)
            refreshChip(t)
            t.setOnFocusChangeListener { v, has ->
                refreshChip(v as TextView)
                if (has) selectTab(i)
            }
            t.setOnClickListener { selectTab(i) }
            tabViews.add(t)
            bar.addView(t, lp())
        }

        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        val clock = TextClock(this).apply {
            format12Hour = "hh:mm a"
            format24Hour = "HH:mm"
            textSize = 20f
            setTextColor(c("#CFD8FF"))
            setPadding(0, 0, dp(16), 0)
        }
        bar.addView(clock)
        bar.addView(chip("👤"), lp())
        return bar
    }

    private fun selectTab(i: Int) {
        if (i == currentTab) return
        currentTab = i
        tabViews.forEachIndexed { j, v ->
            v.tag = (j == i)
            refreshChip(v)
        }
        render()
    }

    // ---------- data ----------
    private fun loadApps() {
        val pm = packageManager
        val map = LinkedHashMap<String, AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || map.containsKey(pkg)) continue
                val banner: Drawable? = try { ri.activityInfo.loadBanner(pm) } catch (e: Exception) { null }
                val icon = banner ?: ri.loadIcon(pm)
                map[pkg] = AppItem(ri.loadLabel(pm).toString(), pkg, icon, banner != null)
            }
        }
        allApps.clear()
        allApps.addAll(map.values.sortedBy { it.label.lowercase() })
    }

    // ---------- rendering ----------
    private fun render() {
        content.removeAllViews()
        heroTitle = null
        heroSub = null
        if (currentTab == 0) renderForYou() else renderApps()
        scroll.scrollTo(0, 0)
    }

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (h) {
            in 5..11 -> "শুভ সকাল"
            in 12..15 -> "শুভ দুপুর"
            in 16..17 -> "শুভ বিকেল"
            in 18..19 -> "শুভ সন্ধ্যা"
            else -> "শুভ রাত্রি"
        }
    }

    private fun renderForYou() {
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(dp(48), dp(16), dp(48), dp(16))
        }
        val ht = TextView(this).apply {
            text = greeting()
            textSize = 38f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val hs = TextView(this).apply {
            text = "OK = খুলুন   •   OK চেপে ধরুন = অপশন (প্রিয়, App Info, আনইনস্টল)"
            textSize = 16f
            setTextColor(c("#9AA7C7"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        hero.addView(ht)
        hero.addView(hs)
        heroTitle = ht
        heroSub = hs
        content.addView(hero, LinearLayout.LayoutParams(MATCH, dp(150)))

        val byPkg = allApps.associateBy { it.pkg }
        val recent = recents().mapNotNull { byPkg[it] }
        val favorites = favs().mapNotNull { byPkg[it] }.sortedBy { it.label.lowercase() }

        if (recent.isNotEmpty()) addRow("সম্প্রতি খোলা", recent.map { appTile(it, "সম্প্রতি খোলা অ্যাপ") })
        if (favorites.isNotEmpty()) addRow("প্রিয় অ্যাপ", favorites.map { appTile(it, "প্রিয় অ্যাপ") })
        addRow("অ্যাপস", allApps.map { appTile(it, "ইনস্টল করা অ্যাপ") })
        addRow("কুইক সেটিংস", quickTiles())
    }

    private fun renderApps() {
        val t = TextView(this).apply {
            text = "সব অ্যাপ (${allApps.size})"
            textSize = 26f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(48), dp(24), dp(48), dp(8))
        }
        content.addView(t)
        val span = maxOf(3, (resources.displayMetrics.widthPixels - dp(80)) / dp(230))
        val rv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, span)
            adapter = TileAdapter(allApps.map { appTile(it, "ইনস্টল করা অ্যাপ") }, true)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(40), dp(8), dp(40), dp(16))
            overScrollMode = View.OVER_SCROLL_NEVER
            isNestedScrollingEnabled = false
        }
        content.addView(rv, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun addRow(title: String, tiles: List<Tile>) {
        val t = TextView(this).apply {
            text = title
            textSize = 20f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(48), dp(12), dp(48), dp(4))
        }
        content.addView(t)
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = TileAdapter(tiles, false)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(40), dp(8), dp(40), dp(16))
            overScrollMode = View.OVER_SCROLL_NEVER
            isNestedScrollingEnabled = false
        }
        content.addView(rv, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    // ---------- tiles ----------
    private fun appTile(a: AppItem, sub: String) =
        Tile(a.label, sub, a.icon, null, a.banner, { launch(a) }, { showOptions(a) })

    private fun quick(emoji: String, label: String, action: String) =
        Tile(label, "কুইক সেটিংস", null, emoji, false, {
            try {
                startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                toast("খোলা যাচ্ছে না")
            }
        }, null)

    private fun quickTiles() = listOf(
        quick("⚙️", "Settings", Settings.ACTION_SETTINGS),
        quick("📶", "Wi-Fi", Settings.ACTION_WIFI_SETTINGS),
        quick("🔵", "Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS),
        quick("🖥️", "Display", Settings.ACTION_DISPLAY_SETTINGS),
        quick("🔊", "Sound", Settings.ACTION_SOUND_SETTINGS)
    )

    // ---------- actions ----------
    private fun launch(a: AppItem) {
        val pm = packageManager
        val i = pm.getLeanbackLaunchIntentForPackage(a.pkg) ?: pm.getLaunchIntentForPackage(a.pkg)
        if (i == null) {
            toast("App খোলা যাচ্ছে না")
            return
        }
        val r = recents()
        r.remove(a.pkg)
        r.add(0, a.pkg)
        prefs.edit().putString("recents", r.take(12).joinToString(",")).apply()
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun showOptions(a: AppItem) {
        val isFav = favs().contains(a.pkg)
        val opts = arrayOf(
            if (isFav) "প্রিয় থেকে সরান" else "প্রিয়তে যোগ করুন",
            "App Info",
            "আনইনস্টল"
        )
        AlertDialog.Builder(this)
            .setTitle(a.label)
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> toggleFav(a.pkg)
                    1 -> openInfo(a.pkg)
                    2 -> uninstall(a.pkg)
                }
            }
            .show()
    }

    private fun toggleFav(pkg: String) {
        val s = favs()
        if (!s.remove(pkg)) s.add(pkg)
        prefs.edit().putStringSet("favs", s).apply()
        render()
        content.post { content.requestFocus() }
    }

    private fun openInfo(pkg: String) {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            toast("App Info খোলা যাচ্ছে না")
        }
    }

    private fun uninstall(pkg: String) {
        try {
            startActivity(
                Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            toast("আনইনস্টল করা যাচ্ছে না")
        }
    }

    private fun openSearch() {
        try {
            startActivity(Intent("android.search.action.GLOBAL_SEARCH").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("Search app পাওয়া যায়নি")
        }
    }

    // ---------- adapter ----------
    private fun cardBg() = GradientDrawable().apply {
        cornerRadius = dp(14).toFloat()
        setColor(c("#2B2F3A"))
    }

    private fun focusStroke() = GradientDrawable().apply {
        cornerRadius = dp(14).toFloat()
        setColor(Color.TRANSPARENT)
        setStroke(dp(3), Color.WHITE)
    }

    inner class TileAdapter(private val tiles: List<Tile>, private val grid: Boolean) :
        RecyclerView.Adapter<TileAdapter.VH>() {

        inner class VH(
            val root: LinearLayout,
            val img: ImageView,
            val emoji: TextView,
            val label: TextView
        ) : RecyclerView.ViewHolder(root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val ctx = parent.context
            val root = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                isFocusable = true
                isClickable = true
                clipChildren = false
                layoutParams = RecyclerView.LayoutParams(if (grid) MATCH else dp(210), WRAP).apply {
                    setMargins(dp(8), dp(6), dp(8), dp(6))
                }
            }
            val card = FrameLayout(ctx).apply {
                background = cardBg()
                clipToOutline = true
            }
            val img = ImageView(ctx)
            val emoji = TextView(ctx).apply {
                textSize = 40f
                gravity = Gravity.CENTER
                visibility = View.GONE
            }
            card.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
            card.addView(emoji, FrameLayout.LayoutParams(MATCH, MATCH))
            root.addView(card, LinearLayout.LayoutParams(MATCH, dp(118)))

            val label = TextView(ctx).apply {
                textSize = 14f
                setTextColor(c("#C9D1E6"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(4), dp(8), dp(4), 0)
            }
            root.addView(label, LinearLayout.LayoutParams(MATCH, WRAP))

            root.setOnFocusChangeListener { v, has ->
                card.foreground = if (has) focusStroke() else null
                v.animate().scaleX(if (has) 1.08f else 1f).scaleY(if (has) 1.08f else 1f).setDuration(120).start()
                label.setTextColor(if (has) Color.WHITE else c("#C9D1E6"))
                if (has) {
                    val t = v.tag as? Tile
                    if (t != null) {
                        heroTitle?.text = t.title
                        heroSub?.text = t.sub
                    }
                }
            }
            return VH(root, img, emoji, label)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val t = tiles[position]
            h.root.tag = t
            h.label.text = t.title
            val icon = t.icon
            if (icon != null) {
                h.emoji.visibility = View.GONE
                h.img.visibility = View.VISIBLE
                h.img.setImageDrawable(icon.constantState?.newDrawable(resources) ?: icon)
                if (t.banner) {
                    h.img.scaleType = ImageView.ScaleType.CENTER_CROP
                    h.img.layoutParams = FrameLayout.LayoutParams(MATCH, MATCH)
                } else {
                    h.img.scaleType = ImageView.ScaleType.FIT_CENTER
                    h.img.layoutParams = FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER)
                }
            } else {
                h.img.visibility = View.GONE
                h.emoji.visibility = View.VISIBLE
                h.emoji.text = t.emoji
            }
            h.root.setOnClickListener { t.onClick() }
            if (t.onLong != null) {
                h.root.setOnLongClickListener { t.onLong.invoke(); true }
            } else {
                h.root.setOnLongClickListener(null)
            }
        }

        override fun getItemCount() = tiles.size
    }
}
